export { default as example } from './example';
