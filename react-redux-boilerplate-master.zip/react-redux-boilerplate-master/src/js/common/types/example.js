export type exampleType = {
  title: string,
  description: string,
  source: string,
}
