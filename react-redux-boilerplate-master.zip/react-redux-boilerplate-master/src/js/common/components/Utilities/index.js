export { default as ErrorBoundary } from './ErrorBoundary';
